package com.mygdx.game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.awt.*;

public class save extends State {
    private Texture sec;
    private Texture background;
    private Texture playBtn;
    private Rectangle playBtnBounds;
    OrthographicCamera camera;

    public Texture getBackground() {
        return background;
    }

    public Texture getPlayBtn() {
        return playBtn;
    }

    public Rectangle getPlayBtnBounds() {
        return playBtnBounds;
    }

    public save(Manager manage) {
        super(manage);
        sec = new Texture("end1.png");
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 1280, 720);
    }

    @Override
    protected void handleInput() {

    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(sec, 0, 0, MyGdxGame.WIDTH, MyGdxGame.HEIGHT);
        sb.end();

    }

    @Override
    public void dispose() {

    }
}

