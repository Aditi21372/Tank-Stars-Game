package com.mygdx.game;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.awt.*;

public class ResumeGame1 extends State {
    private Texture sec;
    private Texture background;
    private Texture playBtn;
    private Rectangle playBtnBounds;
    private Texture playBtn1;
    private Rectangle playBtnBounds1;
    OrthographicCamera camera;

    public Texture getBackground() {
        return background;
    }

    public Texture getPlayBtn() {
        return playBtn;
    }

    public Rectangle getPlayBtnBounds() {
        return playBtnBounds;
    }

    public Texture getPlayBtn1() {
        return playBtn1;
    }

    public void setPlayBtn1(Texture playBtn1) {
        this.playBtn1 = playBtn1;
    }

    public Rectangle getPlayBtnBounds1() {
        return playBtnBounds1;
    }

    public void setPlayBtnBounds1(Rectangle playBtnBounds1) {
        this.playBtnBounds1 = playBtnBounds1;
    }

    public ResumeGame1(Manager manage) {
        super(manage);
        sec = new Texture("savedgame.png");
        playBtn = new Texture("Aditi.png");
        playBtnBounds = new Rectangle(500, 400, 260, 70);
        playBtn1 = new Texture("Kanishk1.png");
        playBtnBounds1 = new Rectangle(493, 200, 268, 110);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 1280, 720);
    }

    @Override
    protected void handleInput() {

    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(sec, 0, 0, MyGdxGame.WIDTH, MyGdxGame.HEIGHT);
        sb.draw(playBtn, playBtnBounds.x, playBtnBounds.y, playBtnBounds.width, playBtnBounds.height);
        sb.draw(playBtn1, playBtnBounds1.x, playBtnBounds1.y, playBtnBounds1.width, playBtnBounds1.height);
        sb.end();

    }

    @Override
    public void dispose() {

    }
}



