package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Loading extends State {
    private Texture sec;
    public Loading(Manager manage) {
        super(manage);
        sec = new Texture("Exit.png");
    }

    @Override
    public void handleInput() {


    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(sec, 0, 0, MyGdxGame.WIDTH, MyGdxGame.HEIGHT);
        sb.end();
    }

    @Override
    public void dispose() {

    }
}
